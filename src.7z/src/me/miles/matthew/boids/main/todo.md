# Todo
- [ ] Viewing angles
- [ ] Pop-out window

## Rules
- Steer away from nearby boids

- Align with nearby boids
	- average direction of visible boids
- Steer towards centre of nearby boids
	- magnet to average coord of visible boids